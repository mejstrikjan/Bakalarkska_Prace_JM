-- --------------------------------------------------------
-- Hostitel:                     127.0.0.1
-- Verze serveru:                10.4.32-MariaDB - mariadb.org binary distribution
-- OS serveru:                   Win64
-- HeidiSQL Verze:               12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Exportování struktury databáze pro
CREATE DATABASE IF NOT EXISTS `reservationsystemvr` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci */;
USE `reservationsystemvr`;

-- Exportování struktury pro tabulka reservationsystemvr.headset
CREATE TABLE IF NOT EXISTS `headset` (
  `headsetID` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(50) NOT NULL,
  PRIMARY KEY (`headsetID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro tabulka reservationsystemvr.payment
CREATE TABLE IF NOT EXISTS `payment` (
  `paymentID` int(11) NOT NULL AUTO_INCREMENT,
  `reservationID` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `paymentMethod` varchar(50) DEFAULT NULL,
  `paymentDate` datetime DEFAULT NULL,
  PRIMARY KEY (`paymentID`),
  KEY `FK_payment_reservation` (`reservationID`),
  CONSTRAINT `FK_payment_reservation` FOREIGN KEY (`reservationID`) REFERENCES `reservation` (`reservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro tabulka reservationsystemvr.reservation
CREATE TABLE IF NOT EXISTS `reservation` (
  `userID` int(11) NOT NULL,
  `reservationID` int(11) NOT NULL AUTO_INCREMENT,
  `creationDate` datetime NOT NULL,
  `reservationDate` datetime NOT NULL,
  `voucherID` int(11) DEFAULT NULL,
  `status` enum('pending','paid','cancelled','completed') NOT NULL DEFAULT 'pending',
  `durationMinutes` int(11) DEFAULT NULL,
  `totalPrice` float DEFAULT NULL,
  PRIMARY KEY (`reservationID`),
  KEY `FK_reservation_voucher` (`voucherID`),
  KEY `FK_reservation_user` (`userID`),
  CONSTRAINT `FK_reservation_user` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_reservation_voucher` FOREIGN KEY (`voucherID`) REFERENCES `voucher` (`voucherID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro tabulka reservationsystemvr.reservation_headset
CREATE TABLE IF NOT EXISTS `reservation_headset` (
  `reservationID` int(11) NOT NULL,
  `headsetID` int(11) NOT NULL,
  PRIMARY KEY (`reservationID`,`headsetID`),
  KEY `FK_reservation_headset_headset` (`headsetID`),
  CONSTRAINT `FK_reservation_headset_headset` FOREIGN KEY (`headsetID`) REFERENCES `headset` (`headsetID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_reservation_headset_reservation` FOREIGN KEY (`reservationID`) REFERENCES `reservation` (`reservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro tabulka reservationsystemvr.user
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `phonenumber` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `passwordHash` varchar(255) NOT NULL DEFAULT '',
  `lastLogin` int(11) DEFAULT NULL,
  `userType` enum('user','admin') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`userID`),
  UNIQUE KEY `UNIQUE` (`email`,`phonenumber`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro tabulka reservationsystemvr.voucher
CREATE TABLE IF NOT EXISTS `voucher` (
  `voucherID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) DEFAULT NULL,
  `expirationDate` datetime DEFAULT NULL,
  `voucherCode` varchar(50) NOT NULL,
  `maxUses` int(11) NOT NULL DEFAULT 1,
  `usedCount` int(11) NOT NULL DEFAULT 0,
  `createDate` datetime DEFAULT NULL,
  PRIMARY KEY (`voucherID`),
  UNIQUE KEY `VoucherCode` (`voucherCode`),
  KEY `FK_voucher_user` (`userID`),
  CONSTRAINT `FK_voucher_user` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Export dat nebyl vybrán.

-- Exportování struktury pro pohled reservationsystemvr.v_admin_reservations
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_admin_reservations` (
	`reservationID` INT(11) NOT NULL,
	`reservationDate` DATETIME NOT NULL,
	`creationDate` DATETIME NOT NULL,
	`durationMinutes` INT(11) NULL,
	`totalPrice` FLOAT NULL,
	`status` ENUM('pending','paid','cancelled','completed') NOT NULL COLLATE 'utf8mb4_czech_ci',
	`name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`sname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`email` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`phonenumber` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`voucherCode` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`headsetModel` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci'
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_admin_vouchers
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_admin_vouchers` (
	`voucherID` INT(11) NOT NULL,
	`voucherCode` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`maxUses` INT(11) NOT NULL,
	`usedCount` INT(11) NOT NULL,
	`expirationDate` DATETIME NULL,
	`userID` INT(11) NULL,
	`name` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`sname` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`email` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`username` VARCHAR(101) NULL COLLATE 'utf8mb4_czech_ci'
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_fully_booked_days
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_fully_booked_days` (
	`date` DATE NULL
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_reservation_overview
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_reservation_overview` (
	`reservationID` INT(11) NOT NULL,
	`userID` INT(11) NOT NULL,
	`customer` VARCHAR(101) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`reservationDate` DATETIME NOT NULL,
	`durationMinutes` INT(11) NULL,
	`totalPrice` FLOAT NULL,
	`status` ENUM('pending','paid','cancelled','completed') NOT NULL COLLATE 'utf8mb4_czech_ci',
	`voucherCode` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`headsetModel` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`paidAmount` DECIMAL(10,2) NULL,
	`paymentMethod` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`paymentDate` DATETIME NULL
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_upcoming_reservations
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_upcoming_reservations` (
	`reservationID` INT(11) NOT NULL,
	`userID` INT(11) NOT NULL,
	`customer` VARCHAR(101) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`reservationDate` DATETIME NOT NULL,
	`durationMinutes` INT(11) NULL,
	`totalPrice` FLOAT NULL,
	`status` ENUM('pending','paid','cancelled','completed') NOT NULL COLLATE 'utf8mb4_czech_ci',
	`voucherCode` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`headsetModel` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`paidAmount` DECIMAL(10,2) NULL,
	`paymentMethod` VARCHAR(50) NULL COLLATE 'utf8mb4_czech_ci',
	`paymentDate` DATETIME NULL
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_user_reservations
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_user_reservations` (
	`reservationID` INT(11) NOT NULL,
	`userID` INT(11) NOT NULL,
	`reservationDate` DATETIME NOT NULL,
	`durationMinutes` INT(11) NULL,
	`totalPrice` FLOAT NULL,
	`status` ENUM('pending','paid','cancelled','completed') NOT NULL COLLATE 'utf8mb4_czech_ci'
) ENGINE=MyISAM;

-- Exportování struktury pro pohled reservationsystemvr.v_user_vouchers
-- Vytváření dočasné tabulky Pohledu pro omezení dopadu chyb
CREATE TABLE `v_user_vouchers` (
	`voucherID` INT(11) NOT NULL,
	`voucherCode` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci',
	`maxUses` INT(11) NOT NULL,
	`usedCount` INT(11) NOT NULL,
	`expirationDate` DATETIME NULL,
	`userID` INT(11) NOT NULL,
	`email` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_czech_ci'
) ENGINE=MyISAM;

-- Exportování struktury pro procedura reservationsystemvr.apply_voucher
DELIMITER //
CREATE PROCEDURE `apply_voucher`(
    IN in_reservationId INT,
    IN in_voucherCode VARCHAR(50),
    IN in_usageCount INT
)
BEGIN
    DECLARE v_voucherId INT;
    DECLARE v_remainingUses INT;

    -- Získání ID voucheru
    SELECT voucherID, (maxUses - usedCount) INTO v_voucherId, v_remainingUses
    FROM voucher
    WHERE voucherCode = in_voucherCode
      AND expirationDate > NOW();

    -- Zkontroluj, že existuje a má dostatek použití
    IF v_voucherId IS NOT NULL AND v_remainingUses >= in_usageCount THEN

        -- Aktualizace rezervace
        UPDATE reservation
        SET voucherID = v_voucherId
        WHERE reservationID = in_reservationId;

        -- Odběr použití
        UPDATE voucher
        SET usedCount = usedCount + in_usageCount
        WHERE voucherID = v_voucherId;

    END IF;
END//
DELIMITER ;

-- Exportování struktury pro procedura reservationsystemvr.cancel_reservation
DELIMITER //
CREATE PROCEDURE `cancel_reservation`(
  IN in_reservationID INT
)
BEGIN
  -- Aktualizace stavu rezervace
  UPDATE reservation
  SET status = 'cancelled'
  WHERE reservationID = in_reservationID;

  -- Smazání případné platby
  DELETE FROM payment
  WHERE reservationID = in_reservationID;
END//
DELIMITER ;

-- Exportování struktury pro procedura reservationsystemvr.create_reservation_with_voucher
DELIMITER //
CREATE PROCEDURE `create_reservation_with_voucher`(
  IN in_userId INT,
  IN in_headsetId INT,
  IN in_reservationDate DATETIME,
  IN in_duration INT,
  IN in_voucherCode VARCHAR(50)
)
BEGIN
  DECLARE voucher_id INT;
  DECLARE available_uses INT;
  DECLARE used_count INT;
  DECLARE price_per_unit DECIMAL(10,2) DEFAULT 10.00;

  DECLARE total_price DECIMAL(10,2);
  DECLARE reservation_status ENUM('pending','paid','cancelled','completed') DEFAULT 'pending';

  DECLARE duration_hours INT;
  DECLARE remaining_minutes INT;
  DECLARE discounted_minutes INT;
  DECLARE paid_minutes INT;

  SET duration_hours = FLOOR(in_duration / 60);
  SET remaining_minutes = in_duration MOD 60;

  -- Výchozí stav
  SET total_price = in_duration * price_per_unit;
  SET discounted_minutes = 0;
  SET paid_minutes = in_duration;

  -- Ověření a načtení voucheru
  IF in_voucherCode IS NOT NULL AND in_voucherCode != '' THEN
    SELECT voucherID, maxUses - usedCount
    INTO voucher_id, available_uses
    FROM voucher
    WHERE voucherCode = in_voucherCode
      AND expirationDate > NOW()
      AND usedCount < maxUses
    LIMIT 1;

    IF voucher_id IS NOT NULL AND available_uses > 0 THEN
      SET discounted_minutes = LEAST(available_uses * 60, in_duration);
      SET paid_minutes = in_duration - discounted_minutes;

      SET total_price = paid_minutes * price_per_unit;

      -- Odečti použití podle využitých hodin
      UPDATE voucher
      SET usedCount = usedCount + FLOOR(discounted_minutes / 60)
      WHERE voucherID = voucher_id;

      IF total_price = 0 THEN
        SET reservation_status = 'paid';
      END IF;
    ELSE
      SET voucher_id = NULL;
    END IF;
  END IF;

  -- Vytvoření rezervace
  INSERT INTO reservation (
    userID, reservationDate, creationDate,
    durationMinutes, totalPrice, status, voucherID
  )
  VALUES (
    in_userId, in_reservationDate, NOW(),
    in_duration, total_price, reservation_status, voucher_id
  );

  SET @new_reservation_id = LAST_INSERT_ID();

  -- Přiřazení headsetu
  INSERT INTO reservation_headset (reservationID, headsetID)
  VALUES (@new_reservation_id, in_headsetId);
END//
DELIMITER ;

-- Exportování struktury pro procedura reservationsystemvr.create_voucher
DELIMITER //
CREATE PROCEDURE `create_voucher`(
	IN `in_userId` INT,
	IN `in_code` VARCHAR(50),
	IN `in_expiration` DATETIME,
	IN `in_maxUses` INT
)
BEGIN
 DECLARE createDate datetime;
 SET createDate = CURRENT_DATE();

    INSERT INTO voucher (userID, voucherCode, expirationDate, maxUses, usedCount,createDate)
    VALUES (in_userId, in_code, in_expiration, in_maxUses, 0,createDate);
END//
DELIMITER ;

-- Exportování struktury pro procedura reservationsystemvr.edit_reservation
DELIMITER //
CREATE PROCEDURE `edit_reservation`(
    IN in_reservationID INT,
    IN in_reservationDate DATETIME,
    IN in_durationMinutes INT,
    IN in_totalPrice FLOAT,
    IN in_status ENUM('pending','paid','cancelled','completed'),
    IN in_voucherID INT
)
BEGIN
    UPDATE reservation
    SET
        reservationDate = in_reservationDate,
        durationMinutes = in_durationMinutes,
        totalPrice = in_totalPrice,
        status = in_status,
        voucherID = in_voucherID
    WHERE reservationID = in_reservationID;
END//
DELIMITER ;

-- Exportování struktury pro procedura reservationsystemvr.register_user
DELIMITER //
CREATE PROCEDURE `register_user`(
    IN in_username VARCHAR(50),
    IN in_email VARCHAR(50),
    IN in_phone VARCHAR(50),
    IN in_name VARCHAR(50),
    IN in_sname VARCHAR(50),
    IN in_passwordHash VARCHAR(255),
    IN in_userType INT
)
BEGIN
    INSERT INTO user (username, email, phonenumber, name, sname, passwordHash, userType)
    VALUES (in_username, in_email, in_phone, in_name, in_sname, in_passwordHash, in_userType);
END//
DELIMITER ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_admin_reservations`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_admin_reservations` AS SELECT
  r.reservationID,
  r.reservationDate,
  r.creationDate,
  r.durationMinutes,
  r.totalPrice,
  r.status,
  u.name,
  u.sname,
  u.email,
  u.phonenumber,
  v.voucherCode,
  h.model AS headsetModel
FROM reservation r
JOIN user u ON r.userID = u.userID
LEFT JOIN voucher v ON r.voucherID = v.voucherID
JOIN reservation_headset rh ON rh.reservationID = r.reservationID
JOIN headset h ON rh.headsetID = h.headsetID ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_admin_vouchers`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_admin_vouchers` AS SELECT
  v.voucherID,
  v.voucherCode,
  v.maxUses,
  v.usedCount,
  v.expirationDate,
  u.userID,
  u.name,
  u.sname,
  u.email,
  CONCAT(COALESCE(u.name, 'Anonymní'), ' ', COALESCE(u.sname, '')) AS username
FROM voucher v
LEFT JOIN user u ON v.userID = u.userID ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_fully_booked_days`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_fully_booked_days` AS SELECT DATE(r.reservationDate) AS date
FROM reservation r
JOIN reservation_headset rh ON r.reservationID = rh.reservationID
WHERE r.status != 'cancelled'
GROUP BY DATE(r.reservationDate)
HAVING COUNT(*) >= (
  SELECT COUNT(*) FROM headset
) * 8 ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_reservation_overview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_reservation_overview` AS SELECT 
  r.reservationID,
  r.userID,
  CONCAT(u.name, ' ', u.sname) AS customer,
  r.reservationDate,
  r.durationMinutes,
  r.totalPrice,
  r.status,
  v.voucherCode,
  h.model AS headsetModel,
  p.amount AS paidAmount,
  p.paymentMethod,
  p.paymentDate
FROM reservation r
JOIN user u ON r.userID = u.userID
LEFT JOIN voucher v ON r.voucherID = v.voucherID
LEFT JOIN reservation_headset rh ON rh.reservationID = r.reservationID
LEFT JOIN headset h ON rh.headsetID = h.headsetID
LEFT JOIN payment p ON r.reservationID = p.reservationID ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_upcoming_reservations`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_upcoming_reservations` AS SELECT *
FROM v_reservation_overview
WHERE reservationDate BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
ORDER BY reservationDate ASC ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_user_reservations`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_user_reservations` AS SELECT
  r.reservationID,
  r.userID,
  r.reservationDate,
  r.durationMinutes,
  r.totalPrice,
  r.status
FROM reservation r ;

-- Odebírání dočasné tabulky a vytváření struktury Pohledu
DROP TABLE IF EXISTS `v_user_vouchers`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_user_vouchers` AS SELECT
  v.voucherID,
  v.voucherCode,
  v.maxUses,
  v.usedCount,
  v.expirationDate,
  u.userID,
  u.email
FROM voucher v
JOIN user u ON v.userID = u.userID ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
